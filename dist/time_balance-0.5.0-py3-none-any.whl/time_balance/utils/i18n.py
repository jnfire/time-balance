import locale
import json
import pathlib
from typing import Dict, Any, Optional

# Private cache to avoid repeated disk reads
_translations_cache: Dict[str, Dict[str, str]] = {}

def _get_locales_dir() -> pathlib.Path:
    """Returns the path to the locales directory."""
    return pathlib.Path(__file__).parent / "locales"

def _load_language_file(lang: str) -> Dict[str, str]:
    """Loads a translation JSON file from disk into the cache."""
    if lang in _translations_cache:
        return _translations_cache[lang]
    
    file_path = _get_locales_dir() / f"{lang}.json"
    if not file_path.exists():
        # Fallback to English if the requested file doesn't exist
        if lang == "en":
            return {}
        return _load_language_file("en")
    
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            translations = json.load(f)
            _translations_cache[lang] = translations
            return translations
    except (json.JSONDecodeError, OSError):
        return _load_language_file("en") if lang != "en" else {}

def get_system_language() -> str:
    """Detects system language using modern locale API, defaults to English."""
    try:
        lang_code, _ = locale.getlocale()
        if not lang_code:
            lang_code = locale.getdefaultlocale()[0]
            
        if lang_code and lang_code.startswith("es"):
            return "es"
    except Exception:
        pass
    return "en"

def resolve_language(language_setting: str) -> str:
    """Resolves 'auto' setting to actual system language."""
    if language_setting == "auto":
        return get_system_language()
    return language_setting

def translate(key: str, lang: str = "en", **kwargs) -> str:
    """Returns the translated string for a given key with fallback to English."""
    # 1. Load target language
    translations = _load_language_file(lang)
    
    # 2. Try to get the key
    text_template = translations.get(key)
    
    # 3. Fallback to English if key is missing in target language
    if text_template is None and lang != "en":
        en_translations = _load_language_file("en")
        text_template = en_translations.get(key, key)
    elif text_template is None:
        text_template = key
        
    try:
        return text_template.format(**kwargs)
    except (KeyError, ValueError):
        return text_template
